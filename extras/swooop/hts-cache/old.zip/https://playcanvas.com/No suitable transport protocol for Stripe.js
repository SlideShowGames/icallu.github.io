<html>
    <head>
        <link rel="stylesheet" href="/css/styles.css"/>
        <title>404 Not Found - PlayCanvas</title>
        <meta name="robots" content="noindex">
        <!-- Google Analytics -->
<script>
window.ga=window.ga||function(){(ga.q=ga.q||[]).push(arguments)};ga.l=+new Date;
ga('create', 'UA-23605814-1', 'auto');
ga('create', 'UA-66543520-1', 'auto', 'jatracker'); // GMO

// for non-angular pages send page views now
if (!document.querySelector("meta[name=fragment]")) {
    ga('send', 'pageview');
    ga('jatracker.send', 'pageview');
}

window.gaRecord = function (category, action, label, value, noninteraction) {
    ga('send', 'event', category, action, label, value, {
        nonInteraction: noninteraction
    });
};
</script>
<script async src='https://www.google-analytics.com/analytics.js'></script>
<!-- End Google Analytics -->

<script type="text/javascript">
    var Keen=Keen||{configure:function(e){this._cf=e},addEvent:function(e,t,n,i){this._eq=this._eq||[],this._eq.push([e,t,n,i])},setGlobalProperties:function(e){this._gp=e},onChartsReady:function(e){this._ocrq=this._ocrq||[],this._ocrq.push(e)}};(function(){var e=document.createElement("script");e.type="text/javascript",e.async=!0,e.src=("https:"==document.location.protocol?"https://":"http://")+"dc8na2hxrj29i.cloudfront.net/code/keen-2.1.0-min.js";var t=document.getElementsByTagName("script")[0];t.parentNode.insertBefore(e,t)})();
    Keen.configure({
        projectId: "51f689fb897a2c086f000000",
        writeKey: "08dabb67df7143737e259be9a262725bef6d5b8c6adae1eac9cef68a662a4f99b886d1cc5a967e2c52605986b2f424e7c7f35551ce5d7ed5079501534db548c22c8b5a6ef3c425eada25ffa6f5bcc290e6d3e662420f29248385127fa1fc82306db64954aae97aee3e352957c553fe92",
    });

    Keen.setGlobalProperties(function (collection) {
        
        return {
            user: {
                id: null,
                created_at: null,
                session_id: common.cookie.get('pc_auth') ? common.cookie.get('pc_auth').replace('"', '') : null
            },
        }

    });
    metrics = {
        sendEvent: function (collection, data) {
            Keen.addEvent(collection, data);
        }
    }

</script>

<script src="/static/platform/js/common/common.js"></script>
<script src="/static/platform/js/common/pageview.js"></script>
<script>
    if (!document.querySelector("meta[name=fragment]")) {
        // track view on non-angular page
        common.analytics.trackPageview();
    }
</script>

        <style>
            #error-page {
                # background-color: #324447;
            }

            img {
                margin-top: 20px;
                margin-bottom: 20px;
            }
        }
        </style>
    </head>
    <body id="error-page">
        <div class="text-center">
            <img src="https://s3-eu-west-1.amazonaws.com/static.playcanvas.com/platform/images/logo/playcanvas-grey-small.png" />
            <h2>Oops... 404 Not Found</h2>
        </div>
    </body>
</html>
